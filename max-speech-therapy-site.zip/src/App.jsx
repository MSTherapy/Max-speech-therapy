
import React from "react";

export default function MaxSpeechTherapy() {
  return (
    <div className="bg-beige min-h-screen text-gray-800 font-sans">
      <section className="bg-green-100 py-16 text-center">
        <h1 className="text-4xl font-bold mb-2">Max Speech Therapy</h1>
        <p className="text-xl italic">Every Step Forward Matters</p>
      </section>

      <section className="py-12 px-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">About Us</h2>
        <p>
          At Max Speech Therapy, we believe that every child deserves the chance to communicate with confidence.
          We provide individualized speech and feeding therapy services across South Florida, focused on celebrating
          progress—no matter how big or small.
        </p>
      </section>

      <section className="bg-green-50 py-12 px-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Our Services</h2>
        <ul className="list-disc list-inside">
          <li>Speech and Language Evaluations</li>
          <li>Articulation and Phonological Therapy</li>
          <li>Early Language Development</li>
          <li>Feeding Therapy</li>
          <li>Parent Coaching and Support</li>
        </ul>
      </section>

      <section className="py-12 px-6 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
        <form className="grid grid-cols-1 gap-4">
          <input type="text" placeholder="Your Name" className="border p-2 rounded" />
          <input type="email" placeholder="Your Email" className="border p-2 rounded" />
          <textarea placeholder="Your Message" className="border p-2 rounded" rows={4} />
          <button type="submit" className="bg-green-600 text-white p-2 rounded w-full">Send Message</button>
        </form>
      </section>

      <section className="bg-green-100 py-8 text-center">
        <p className="mb-2">New to Max Speech Therapy?</p>
        <a 
          href="/Max_Speech_Therapy_Intake_Form_With_Privacy_Notice.docx" 
          className="text-green-800 underline font-medium"
        >
          Download New Patient Intake Form
        </a>
      </section>
    </div>
  );
}
